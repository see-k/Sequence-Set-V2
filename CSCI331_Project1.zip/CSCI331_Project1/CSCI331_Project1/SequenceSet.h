#pragma once
//Test
#ifndef _SEQUENCE_SET_
#define _SEQUENCE_SET_

#include "pch.h"
#include <fstream>
#include <iostream>
#include <string>

using namespace std;

class SequenceSet
{
private:
	const static int MAX_FIELDS = 7;
	const static int MAX_RECORDS = 100000;
	const static int BLOCK_SIZE = 4;
	const static int BLOCK_FILL = 3;
	int NumRecords = 0;
	int NumBlocks = 0;
	int RecordLength = 81;
	int BlockSpacerLength = 4;
	int BlockLength = (BLOCK_SIZE * RecordLength);
	int NumFields;
	string ListName;
	ofstream Index;
	ofstream List;
	ifstream Input;
	
	int IndexKey[MAX_RECORDS] = { 0 };
	int IndexAddress[MAX_RECORDS] = { 0 };

	struct Field 
	{
		 string FieldName;
		unsigned int StartPosition;
		unsigned int StopPosition;
		string type;
	};
	
	struct Record
	{
		unsigned int Zip = 0;
		string Place = "";
		string State = "";
		string County = "";
		float Latitude = 0;
		float Longitude = 0;
	};

	struct Block
	{
		Record Records[BLOCK_SIZE];
	};

	// Prints all of the information in a record.
	void PrintRecord(Record ToPrint);

	// Searches recursively for a specific item.
	int binarySearch(int arr[], int l, int r, int x);

	// Returns the offset for a block with a certain zip code.
	int Search(int Zip);

	Block GetBlock(int ByteOffset);

	Field Fields[MAX_FIELDS];

public:
	
	// Constructor
	SequenceSet()
	{
		//Index.open("TestIndex");
		//List.open("TestList");
	}

	// Populates the Sequence Set
	void PopulateSequenceSet(string input);

	// Searches for a record that contains a certain zip code.
	void ZipSearch(int Zipcode);

	// Searches for Northernmost, Southernmost, Easternmost, and Westernmost Zip Codes in a State.
	void StateSearch(string State);

}; //end

//#include "SequenceSet.cpp"

#endif