// CSCI331_Project1.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include "pch.h"
#include <iostream>
#include "SequenceSet.h"
//#include "SequenceSet.cpp"

using namespace std;

void DisplayMenu()
{
	cout << "\nTEST PROGRAM MENU\n";
	cout << "Enter 1-4 to do the following (Sequence Set must be Populated to use Search functions):\n";
	cout << "1. Populate the Sequence Set.\n";
	cout << "2. Search for Northernmost, Southernmost, Easternmost, and Westernmost Zip Codes in a State.\n";
	cout << "3. Search for a specific Zip Code.\n";
	cout << "4. Exit Program.\n";
	return;
}

int main()
{
	SequenceSet Test;
	int UserInput = 0;
	string StateInput;
	int ZipCodeInput;
	while (UserInput != 4)
	{
		DisplayMenu();
		cin >> UserInput;

		if (UserInput == 1)
		{
			Test.PopulateSequenceSet("TestInput.txt");
			cout << "\nSequence Set Populated\n";
		}
		else if(UserInput == 2)
		{
			cout << "\nEnter the State you would like to search through in abbreviated form (For Example, MN for Minnesota): \n";
			cin >> StateInput;
			Test.StateSearch(StateInput);
		}
		else if (UserInput == 3)
		{
			cout << "\nEnter the Zip Code you would like to search for: \n";
			cin >> ZipCodeInput;
			Test.ZipSearch(ZipCodeInput);
		}
		else if (UserInput != 4)
		{
			cout << "\nInvalid input, try again.\n";
		}
	}
	cout << "\nCLEAN EXIT\n";

	return 0;
}

